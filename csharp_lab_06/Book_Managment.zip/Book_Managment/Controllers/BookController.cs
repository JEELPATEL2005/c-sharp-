﻿

using LAB_06_CE041.Models;
using Microsoft.AspNetCore.Mvc;

namespace LAB_06_CE041.Controllers
{
    public class BookController : Controller
    {
        private static List<Book> books = new List<Book>
        {
            new Book
            {
                BookId = 1,
                Title = "Clean Code",
                Author = "Robert C. Martin",
                Category = "Programming",
                Price = 500,
                PublishedYear = 2008
            },

            new Book
            {
                BookId = 2,
                Title = "The Pragmatic Programmer",
                Author = "Andrew Hunt",
                Category = "Programming",
                Price = 600,
                PublishedYear = 1999
            }
        };

        // GET: /Book/Index
        public IActionResult Index()
        {
            return View(books);
        }

        // GET: /Book/Details/1
        public IActionResult Details(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // GET: /Book/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Book/Create
        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                book.BookId = books.Count == 0
                    ? 1
                    : books.Max(b => b.BookId) + 1;

                books.Add(book);

                return RedirectToAction(nameof(Index));
            }

            return View(book);
        }

        // GET: /Book/Edit/1
        public IActionResult Edit(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: /Book/Edit
        [HttpPost]
        public IActionResult Edit(Book book)
        {
            if (ModelState.IsValid)
            {
                var existingBook = books.FirstOrDefault(
                    b => b.BookId == book.BookId
                );

                if (existingBook == null)
                {
                    return NotFound();
                }

                existingBook.Title = book.Title;
                existingBook.Author = book.Author;
                existingBook.Category = book.Category;
                existingBook.Price = book.Price;
                existingBook.PublishedYear = book.PublishedYear;

                return RedirectToAction(nameof(Index));
            }

            return View(book);
        }

        // GET: /Book/Delete/1
        public IActionResult Delete(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: /Book/Delete/1
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book == null)
            {
                return NotFound();
            }

            books.Remove(book);

            return RedirectToAction(nameof(Index));
        }
    }
}