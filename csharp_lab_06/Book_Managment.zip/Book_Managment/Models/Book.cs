﻿namespace LAB_06_CE041.Models
{
  
        public class Book
        {
            public int BookId { get; set; }

            public string Title { get; set; }

            public string Author { get; set; }

            public string Category { get; set; }

            public decimal Price { get; set; }

            public int PublishedYear { get; set; }
        }
    }    
    

