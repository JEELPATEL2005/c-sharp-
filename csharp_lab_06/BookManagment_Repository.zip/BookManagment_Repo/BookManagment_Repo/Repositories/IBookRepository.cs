﻿using BookManagment_Repo.Models;

namespace BookManagment_Repo.Repositories
{
    public interface IBookRepository
    {
        List<Book> GetAll();

        // Get a single book by ID
        Book? GetById(int id);

        // Add a new book
        void Add(Book book);

        // Update existing book
        void Update(Book book);

        // Delete book
        void Delete(int id);
    }
}
