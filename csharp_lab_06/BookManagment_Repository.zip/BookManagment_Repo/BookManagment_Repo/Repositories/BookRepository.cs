﻿
using BookManagment_Repo.Models;

namespace BookManagment_Repo.Repositories
{
    public class BookRepository : IBookRepository
    {

        private static List<Book> books = new List<Book>
        {
            new Book
            {
                BookId = 1,
                Title = "Clean Code",
                Author = "Robert C. Martin",
                Category = "Programming",
                Price = 500,
                PublishedYear = 2008
            },

            new Book
            {
                BookId = 2,
                Title = "The Pragmatic Programmer",
                Author = "Andrew Hunt",
                Category = "Programming",
                Price = 600,
                PublishedYear = 1999
            }
        };

        // READ - Get all books
        public List<Book> GetAll()
        {
            return books;
        }

        // READ - Get book by ID
        public Book? GetById(int id)
        {
            return books.FirstOrDefault(b => b.BookId == id);
        }

        // CREATE - Add new book
        public void Add(Book book)
        {
            book.BookId = books.Count == 0
                ? 1
                : books.Max(b => b.BookId) + 1;

            books.Add(book);
        }

        // UPDATE - Update existing book
        public void Update(Book book)
        {
            var existingBook = books.FirstOrDefault(
                b => b.BookId == book.BookId
            );

            if (existingBook != null)
            {
                existingBook.Title = book.Title;
                existingBook.Author = book.Author;
                existingBook.Category = book.Category;
                existingBook.Price = book.Price;
                existingBook.PublishedYear = book.PublishedYear;
            }
        }

        // DELETE - Delete book
        public void Delete(int id)
        {
            var book = books.FirstOrDefault(
                b => b.BookId == id
            );

            if (book != null)
            {
                books.Remove(book);
            }
        }
    }
    
    
}
