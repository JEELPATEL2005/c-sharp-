using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookManagment_Repo.Views.Book
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
