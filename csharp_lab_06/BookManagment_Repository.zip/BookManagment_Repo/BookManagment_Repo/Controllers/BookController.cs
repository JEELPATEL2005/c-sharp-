using BookManagment_Repo.Models;
using BookManagment_Repo.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace BookManagment_Repo.Controllers
{
    public class BookController : Controller
    {
        private readonly IBookRepository _bookRepository;

        // Constructor Injection
        public BookController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        // GET: /Book/Index
        public IActionResult Index()
        {
            var books = _bookRepository.GetAll();

            return View(books);
        }

        // GET: /Book/Details/1
        public IActionResult Details(int id)
        {
            var book = _bookRepository.GetById(id);

            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // GET: /Book/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Book/Create
        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _bookRepository.Add(book);

                return RedirectToAction(nameof(Index));
            }

            return View(book);
        }

        // GET: /Book/Edit/1
        public IActionResult Edit(int id)
        {
            var book = _bookRepository.GetById(id);

            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: /Book/Edit
        [HttpPost]
        public IActionResult Edit(Book book)
        {
            if (ModelState.IsValid)
            {
                var existingBook = _bookRepository.GetById(book.BookId);

                if (existingBook == null)
                {
                    return NotFound();
                }

                _bookRepository.Update(book);

                return RedirectToAction(nameof(Index));
            }

            return View(book);
        }

        // GET: /Book/Delete/1
        public IActionResult Delete(int id)
        {
            var book = _bookRepository.GetById(id);

            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: /Book/Delete/1
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var book = _bookRepository.GetById(id);

            if (book == null)
            {
                return NotFound();
            }

            _bookRepository.Delete(id);

            return RedirectToAction(nameof(Index));
        }
    }
}
